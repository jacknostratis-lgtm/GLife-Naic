const messengerLink = '#'; // set to 'https://m.me/yourpage' when ready
const fbLink = '#';
const igLink = '#';
const ttLink = '#';
document.addEventListener('DOMContentLoaded', () => {
  const msgBtn = document.getElementById('msgBtn');
  if (msgBtn && messengerLink) msgBtn.href = messengerLink;
  const f = document.getElementById('fbLink'); if (f) f.href = fbLink;
  const i = document.getElementById('igLink'); if (i) i.href = igLink;
  const t = document.getElementById('ttLink'); if (t) t.href = ttLink;
});